// Copyright (c) 2009-2015 Tim Serong <tserong@suse.com>
// See COPYING for license.

//= require_self
//= require jquery/locale/validate/messages_ru
//= require bootstrap/locale/table/messages_ru_RU
