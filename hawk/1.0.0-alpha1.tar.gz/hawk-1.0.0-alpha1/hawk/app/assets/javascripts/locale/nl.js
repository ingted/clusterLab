// Copyright (c) 2009-2015 Tim Serong <tserong@suse.com>
// See COPYING for license.

//= require_self
//= require jquery/locale/validate/messages_nl
//= require jquery/locale/validate/methods_nl
//= require bootstrap/locale/table/messages_nl_NL
