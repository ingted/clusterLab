// Copyright (c) 2009-2015 Tim Serong <tserong@suse.com>
// See COPYING for license.

//= require_self
//= require jquery/locale/validate/messages_de
//= require jquery/locale/validate/methods_de
//= require bootstrap/locale/table/messages_de_DE
