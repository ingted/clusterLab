Chef::Config.ssl_verify_mode = :verify_peer
Chef::Config.zypper_check_gpg = true
